// bing-search.ts —— 必应直连搜索扩展（国内稳定、不依赖代理）
// 注册工具：bing_search。作为 pi-web-access(websearch/DDG) 在关闭代理时的兜底引擎。
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";

function decode(s: string): string {
  return s
    .replace(/<[^>]+>/g, "")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ")
    .trim();
}

export default function (pi: ExtensionAPI) {
  pi.registerTool({
    name: "bing_search",
    label: "必应搜索",
    description:
      "用必应（cn.bing.com）搜索网页：国内直连、无需代理、无需 API key。返回标题、链接、摘要列表。适合查资料/文档/新闻，是 websearch（走代理的 DDG）关闭代理时的兜底引擎。",
    parameters: Type.Object({
      query: Type.String({ description: "搜索关键词" }),
      num: Type.Optional(Type.Number({ description: "返回条数 1-20，默认 8" })),
    }),
    async execute(_toolCallId, params, signal) {
      const num = Math.min(Math.max(Math.floor(params.num ?? 8), 1), 20);
      const url =
        `https://cn.bing.com/search?q=${encodeURIComponent(params.query)}` +
        `&count=${num}&setlang=zh-hans&mkt=zh-CN`;
      const res = await fetch(url, {
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
          "Accept-Language": "zh-CN,zh;q=0.9",
        },
        signal,
      });
      if (!res.ok) throw new Error(`必应返回 HTTP ${res.status}`);
      const html = await res.text();
      const results: { title: string; url: string; snippet: string }[] = [];
      const re =
        /<li class="b_algo"[\s\S]*?<h2[^>]*><a[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a><\/h2>([\s\S]*?)<\/li>/g;
      let m: RegExpExecArray | null;
      while ((m = re.exec(html)) && results.length < num) {
        const p = m[3].match(/<p[^>]*>([\s\S]*?)<\/p>/);
        results.push({
          url: decode(m[1]),
          title: decode(m[2]),
          snippet: p ? decode(p[1]) : "",
        });
      }
      if (results.length === 0)
        throw new Error("必应未解析出结果（页面结构变化或触发风控），请改用 websearch 工具");
      const text = results
        .map((r, i) => `${i + 1}. ${r.title}\n   ${r.url}\n   ${r.snippet}`)
        .join("\n\n");
      return {
        content: [
          {
            type: "text",
            text: `「${params.query}」必应搜索结果 ${results.length} 条：\n\n${text}`,
          },
        ],
        details: { count: results.length },
      };
    },
  });
}
