---
name: network-fix
description: 本机网络排障：代理 fake-ip DNS 劫持导致装包/搜索失败时的标准修复流程（DoH 取真实 IP 写 hosts）、代理开关判断、pip/npm 源配置。当出现域名解析异常、下载失败时使用。
---

# 网络排障（本机特化）

## 病根
用户系统代理是 fake-ip 模式：Termux 里的直连请求会被劫持到假 IP，表现为
`npm install` / `git clone` / `curl` 卡死或证书错误；而走代理的流量正常。

## 判断
```bash
getent hosts registry.npmjs.org   # 若解析到 198.18.x.x = fake-ip 劫持实锤
curl -sI --max-time 5 https://registry.npmjs.org   # 卡住=劫持
```

## 修复（标准三步）
```bash
# 1. 用阿里 DoH 取真实 IP
nslookup registry.npmjs.org 223.5.5.5
# 2. 写入 hosts（已有条目则替换）
echo "真实IP registry.npmjs.org" >> $PREFIX/etc/hosts
# 3. 验证直连恢复
curl -sI --max-time 5 https://registry.npmjs.org | head -1
```
常用域名真实 IP 沉淀见 `$PREFIX/etc/hosts` 现有注释。

## 兜底路由
- 代理开着 → `websearch`（DDG，走代理）
- 代理关了 → `bing_search`（必应直连，自研扩展）
- 中文资讯/要综合答案 → `glm_search`（需智谱账户有搜索余额，Coding 套餐不含）
- npm 慢 → 已配清华源；仍失败按上面三步修 hosts
