---
name: phone-cleanup
description: Android 手机安全清理流程：查存储大头、可逆卸载/禁用、trim-caches、向用户确认清单。当用户抱怨存储满、想清理手机时使用。
---

> ⚠️ 本技能原为 ZeroTermux 侧编写，提及 adbc/termux 命令处在本环境（com.pihost）一律不存在。等价能力请用 MCP 工具：l2_exec / env_run / ui_* / vd（见 phone-control 与 silent-control 技能）。以下原文仅作能力对照参考。


# 手机清理（安全版）

2026-08-31 实战沉淀：232G 用 216G 时清出 12G+ 的流程。

## 1. 体检（先看大头再动手）
```bash
adbc shell dumpsys diskstats | head -20      # 各类数据占比
adbc shell df -h /sdcard                      # 总量
adbc shell pm list packages -3 | sort        # 第三方应用列表
```
经验：大头通常在 App 数据（Telegram/微信缓存），而非照片视频。

## 2. 处置阶梯（从轻到重）
1. **删明确垃圾**：Download 安装包、空壳目录（先 ls 确认内容再删）
2. **可逆卸载**：`adbc shell pm uninstall --user 0 包名`（系统应用可 `cmd package install-existing 包名` 一秒恢复）
3. **禁用**（MIUI 保护拒卸时）：`pm disable-user 包名`，恢复=`pm enable 包名`
4. **trim**：`adbc shell cmd activity trim-caches 999G`
5. **App 内清缓存**（Telegram/微信等大户）：只能用户自己在 App 里清，给出操作指引

## 3. 纪律
- 每一步前向用户列出清单等确认；卸载后逐条记录「包名 + 恢复命令」到会话日志
- 用户换机带来的新 App、萤石/九号/美的等生活 App 默认保留
- 警惕清理类 App（本机已禁用系统广告/分析组件，见日志 2026-08-31 续4）
