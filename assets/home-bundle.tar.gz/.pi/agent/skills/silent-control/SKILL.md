# 隐形后台操控（silent-control）

在隐形虚拟副屏上操作任意 App，用户主屏完全无感。适用于：用户在用手机时你悄悄完成任务、自动化巡检、批量操作。

## 标准操作循环

1. `vd {action:"create"}` → 返回 displayId（如 7）
2. `vd {action:"launch", pkg:"包名"}` → 目标 App 发射到副屏
3. `wait_node {text:"页面标志文本", display:7}` → 等页面就绪
4. `ui_screen_read {display:7}` → 读副屏结构树（编号/文本/坐标/可点击）
5. `ui_tap_node {i:节点编号, display:7}` → 按编号点击（免算坐标，最可靠）
6. `wait_node` 再验证目标内容出现 → 形成闭环
7. 完成：`vd {action:"stop"}` 销毁（自动清理 App 防回迁）

## 列表/信息流类 App（抖音/淘宝/小红书/外卖）

- 滚动找目标：`vd {action:"scroll_until", text:"目标文本"}`（自动滑+查树最多8轮）
- 长按：`vd {action:"longpress", x, y, ms:600}`
- 返回/主页：`vd {action:"key", text:"back"}`（back/home/enter）
- 树已自动剔除屏外虚拟节点，别担心节点爆炸
- 输入中文用 `ui_set_text {display:N}`（点输入框获得焦点后）；input text 只适合 ASCII

## 要点

- 结构树优先于截图：树里有精确坐标和文本，比视觉猜坐标可靠得多
- 坐标取 xy 区域中心：x + w/2, y + h/2
- 滑动：`vd {action:"swipe", x, y, x2, y2}`（副屏坐标系 900x2000）
- 文字输入：`vd {action:"text", text:"..."}`（空格用 %s）
- 看一眼画面：`vd {action:"shot"}` 返回 PNG 路径（视觉辅助/调试用）
- displayId 每次创建会变，以 create 返回为准；App 重启后副屏失效需重建
- launch 走 L2 shell 兜底（MIUI 拦 App 内通道），耗时 2-5 秒属正常
- 支付/发送/删除类破坏性操作，副屏上也必须先问用户

## 锁屏限制

设备锁屏时系统禁止任何 App 渲染（vd launch 会返回 LOCKED 错误）。此时只能：
- L1 命令级操作（sysctl/l2_exec/settings）照常可用
- 请用户解锁手机后再做界面类操作

## 常用包名

- 设置 com.android.settings · 微信 com.tencent.mm · 支付宝 com.eg.android.AlipayGphone
- 相册 com.miui.gallery · 时钟 com.android.deskclock · 计算器 com.miui.calculator
