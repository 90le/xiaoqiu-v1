// glm-search.ts —— 智谱 GLM 联网搜索扩展
// 调用智谱开放平台 chat/completions + 内置 web_search 工具（服务端搜索，中文质量高）。
// 认证：复用 pi 的 zai-coding-cn key（~/.pi/agent/auth.json），密钥不落地、不打印。
// ⚠️ 前提：智谱账户需有余额/资源包——Coding 套餐不含搜索额度（缺余额时报 1113 清晰可见）。
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import fs from "node:fs";

function loadKey(): string {
  const p = process.env.HOME + "/.pi/agent/auth.json";
  const a = JSON.parse(fs.readFileSync(p, "utf8"));
  const key = a["zai-coding-cn"]?.key;
  if (!key) throw new Error("auth.json 里没有 zai-coding-cn 的 key");
  return key;
}

export default function (pi: ExtensionAPI) {
  pi.registerTool({
    name: "glm_search",
    label: "智谱联网搜索",
    description:
      "智谱 GLM 服务端联网搜索：返回 AI 综合答案+来源列表，中文资讯质量高。按次计费（约1分钱级），需要智谱账户有余额。查询不受代理开关影响（走智谱服务器）。",
    parameters: Type.Object({
      query: Type.String({ description: "搜索关键词" }),
    }),
    async execute(_toolCallId, params, signal) {
      const key = loadKey();
      const r = await fetch("https://open.bigmodel.cn/api/paas/v4/chat/completions", {
        method: "POST",
        headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "glm-4.6",
          stream: false,
          messages: [{ role: "user", content: params.query }],
          tools: [{ type: "web_search", web_search: { enable: true } }],
        }),
        signal,
      });
      const j: any = await r.json().catch(() => null);
      if (!r.ok || j?.error) {
        const code = j?.error?.code ?? r.status;
        const msg = j?.error?.message ?? "未知错误";
        if (String(code) === "1113")
          throw new Error("智谱余额不足（1113）：给 open.bigmodel.cn 账户充值后本工具即生效");
        throw new Error(`智谱搜索失败 ${code}: ${msg}`);
      }
      const msg = j.choices?.[0]?.message ?? {};
      const sr: any[] = msg.tool_calls?.[0]?.search_result ?? [];
      const parts: string[] = [];
      if (msg.content) parts.push(`【答案】\n${msg.content}`);
      if (sr.length) {
        const list = sr
          .slice(0, 10)
          .map((s, i) => `${i + 1}. ${(s.title || s.media_title || "").trim()} — ${s.link || s.url || ""}`)
          .join("\n");
        parts.push(`【来源】${sr.length} 条\n${list}`);
      }
      if (!parts.length) throw new Error("智谱返回了空结果");
      return {
        content: [{ type: "text", text: parts.join("\n\n") }],
        details: { sources: sr.length },
      };
    },
  });
}
