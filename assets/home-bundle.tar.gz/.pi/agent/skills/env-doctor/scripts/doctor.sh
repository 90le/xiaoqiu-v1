#!/data/data/com.termux/files/usr/bin/bash
# doctor.sh —— 环境自检：一条命令全面体检本机基础设施
C_OK="✅"; C_WARN="⚠"; C_BAD="❌"
pass=0; warn=0; fail=0
chk(){ # $1=结果(ok/warn/bad) $2=描述
  case "$1" in
    ok) echo "$C_OK $2"; pass=$((pass+1));;
    warn) echo "$C_WARN $2"; warn=$((warn+1));;
    *) echo "$C_BAD $2"; fail=$((fail+1));;
  esac
}

echo "═══ 环境自检 $(date '+%F %T') ═══"

# 1. 核心命令
for c in pi node python git tmux rclone adbc; do
  command -v $c >/dev/null && chk ok "$c" || chk bad "$c 缺失"
done

# 2. 服务状态
export SVDIR=$PREFIX/var/service
for s in crond pi-web-ui; do
  case "$(sv status $s 2>/dev/null)" in run:*) chk ok "服务 $s 运行中";; *) chk bad "服务 $s 未运行（sv up $s）";; esac
done

# 3. crontab
n=$(crontab -l 2>/dev/null | grep -cE "autosave|morning-brief|watchdog")
[ "$n" -ge 3 ] && chk ok "定时任务 $n/3（存档/简报/看门狗）" || chk warn "定时任务只有 $n/3"

# 4. 档案 + git
[ -d ~/工程档案/.git ] && chk ok "档案已版本化（$(git -C ~/工程档案 rev-parse --short HEAD 2>/dev/null)）" || chk bad "档案未版本化"
[ -w ~/工程档案/会话日志.md ] && chk ok "档案可写" || chk bad "档案不可写"

# 5. 存储
avail=$(df -h $HOME 2>/dev/null | tail -1 | awk '{print $4}' | tr -d 'G,M')
unit=$(df -h $HOME 2>/dev/null | tail -1 | awk '{print $4}' | grep -o 'G\|M')
case "$unit" in G) [ "${avail%%.*}" -ge 10 ] 2>/dev/null && chk ok "Termux 空间余 ${avail}G" || chk warn "Termux 空间仅余 ${avail}G";; M) chk bad "Termux 空间仅余 ${avail}M";; esac

# 6. 网络（直连+镜像）
timeout 6 curl -sI https://mirrors.tuna.tsinghua.edu.cn -o /dev/null 2>/dev/null && chk ok "网络/清华源可达" || chk warn "网络或镜像异常（见 network-fix 技能）"

# 7. adbc
timeout 15 adbc shell echo ok >/dev/null 2>&1 && chk ok "adbc 手机通道" || chk warn "adbc 不通（无线调试开关可能关了）"

# 8. 会话记录
newest=$(find ~/.pi/agent/sessions -name "*.jsonl" -mmin -1440 2>/dev/null | wc -l)
[ "$newest" -ge 1 ] && chk ok "24h 内有会话记录" || chk warn "24h 无会话记录"

# 9a. pi 桥 App
curl -s --max-time 4 -X POST http://127.0.0.1:8181/api/tools_list -o /dev/null 2>/dev/null && chk ok "pi 桥 MCP (8099)" || chk warn "pi 桥 MCP 不通（点图标或 am startservice）"

# 9a. pi 桥连通
curl -s --max-time 5 -X POST http://127.0.0.1:8181/mcp -H "Content-Type: application/json" -d "{}" >/dev/null 2>&1 && chk ok "pi 桥 App (MCP 8099)" || chk warn "pi 桥未响应（am start 拉起）"

# 9b. 护栏在位
[ -f ~/.pi/agent/extensions/guardrail.ts ] && chk ok "安全护栏 guardrail.ts" || chk bad "护栏缺失！从 档案/backup/extensions/ 恢复"

# 9c. pi 桥 App
curl -s --max-time 5 -X POST http://127.0.0.1:8181/api/battery_status -o /dev/null 2>/dev/null && chk ok "pi 桥 App（MCP 8099）" || chk warn "pi 桥未运行（点图标或 am start 拉起）"

# 9. 文档库
python -c "import docx, openpyxl, pypdf, pptx" 2>/dev/null && chk ok "文档处理库" || chk warn "文档库不全"

echo "═══ 结果: $pass 正常 / $warn 警告 / $fail 故障 ═══"
[ $fail -gt 0 ] && echo "→ 优先处理 ❌ 项；网络问题用 network-fix 技能；闪退恢复用 crash-recovery 技能"
exit 0
